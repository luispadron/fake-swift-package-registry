# ``Atomics/AtomicUpdateOrdering``

## Topics

### Ordering Values

- ``relaxed``
- ``acquiring``
- ``releasing``
- ``acquiringAndReleasing``
- ``sequentiallyConsistent``
