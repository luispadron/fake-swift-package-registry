# ``Atomics/ManagedAtomicLazyReference``

## Topics

### Related Types

- ``Value``

### Initializers

- ``init()``

### Atomic Operations

- ``load()``
- ``storeIfNilThenLoad(_:)``
