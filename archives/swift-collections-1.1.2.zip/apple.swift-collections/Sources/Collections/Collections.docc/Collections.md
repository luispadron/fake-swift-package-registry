# ``Collections``

**Swift Collections** is an open-source package of data structure implementations for the Swift programming language.

## Overview



#### Additional Resources

- [`Swift Collections` on GitHub](https://github.com/apple/swift-collections/)
- [`Swift Collections` on the Swift Forums](https://forums.swift.org/c/related-projects/collections/72)


## Topics

### Bit Collections

- ``BitSet``
- ``BitArray``

### Deque Module

- ``Deque``

### Heap Module

- ``Heap``

### Ordered Collections

- ``OrderedSet``
- ``OrderedDictionary``

### Persistent Hashed Collections

- ``TreeSet``
- ``TreeDictionary``
