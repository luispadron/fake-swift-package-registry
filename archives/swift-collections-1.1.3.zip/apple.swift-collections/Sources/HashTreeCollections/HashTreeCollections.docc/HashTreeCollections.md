# ``HashTreeCollections``

**Swift Collections** is an open-source package of data structure implementations for the Swift programming language.

## Overview



#### Additional Resources

- [`Swift Collections` on GitHub](https://github.com/apple/swift-collections/)
- [`Swift Collections` on the Swift Forums](https://forums.swift.org/c/related-projects/collections/72)


## Topics

### Persistent Collections

- ``TreeSet``
- ``TreeDictionary``
