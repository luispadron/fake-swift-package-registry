# ``_NIOFileSystem/WritableFileHandleProtocol``

## Topics

### Write bytes to a file

- ``write(contentsOf:toAbsoluteOffset:)-57fnc``
- ``write(contentsOf:toAbsoluteOffset:)-4na03``
- ``bufferedWriter(startingAtAbsoluteOffset:capacity:)``

### Resize a file
- ``resize(to:)``
