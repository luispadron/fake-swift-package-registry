# NIOTCPEchoClient

This sample application provides a simple TCP echo client that will send multiple messages to an
echo server and wait for a response of all of them. Before running this client, make sure to start
the `NIOTCPEchoServer`.

To run this client execute the following from the root of the repository:

```bash
swift run NIOTCPEchoClient
```
