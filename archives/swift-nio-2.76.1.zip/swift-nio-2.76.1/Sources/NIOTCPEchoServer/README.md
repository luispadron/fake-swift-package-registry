# NIOTCPEchoServer

This sample application provides a simple TCP server that sends clients back whatever they send it.

To run this server execute the following from the root of the repository:

```bash
swift run NIOTCPEchoServer
```

You can then use the `NIOTCPClient` to send requests to the server.
