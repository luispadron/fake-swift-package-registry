This file exists so that the containing directory is not empty.
