# Test Data

This directory contains known files and directories for integration testing. This avoids having to
rely on APIs for creating files and directories in order to test APIs which read files and
directories.
